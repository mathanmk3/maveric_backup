import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BookmyticketComponent } from './bookmyticket.component';

describe('BookmyticketComponent', () => {
  let component: BookmyticketComponent;
  let fixture: ComponentFixture<BookmyticketComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BookmyticketComponent]
    });
    fixture = TestBed.createComponent(BookmyticketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
