import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { BookingService } from '../Service/booking.service';
import { catchError } from 'rxjs';



@Component({
  selector: 'app-bookmyticket',
  templateUrl: './bookmyticket.component.html',
  styleUrls: ['./bookmyticket.component.css']
})


export class BookmyticketComponent {

  customersD!: any;
  errorMessage: string | undefined;

  ticketDetails = this.fbr.group({
    tainName: ['gghh'],
    trainNumber: [''],
    startPoint: [''],
    endPoint: [''],
    startDateAndTime: [''],
    destinationDateAndTime: [''],
    PNRNumber: [''],
    seatFromTo: [''],
    noOfSeats: [''],
    boardingPoint: [''],
    destinationPoint: [''],
    ticketStatus: [''],
    ticketStatusUpdatedDateAndTime: [''],
    seatStatus: ["Completed"],
 })

  constructor(private fbr: FormBuilder,private route :Router,public bookingService:BookingService,private ar: ActivatedRoute,){}  
  ngOnInit(): void {
   this.bookTicketAutomatically()
  }

   bookTicketAutomatically() {
     this.bookingService.automaticTicketBooking().subscribe((x)=> {
       this.route.navigateByUrl("/dhashboard")
   })
}


}


