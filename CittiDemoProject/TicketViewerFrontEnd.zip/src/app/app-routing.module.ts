import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MybookingComponent } from './mybooking/mybooking.component';
import { HeaderComponent } from './header/header.component';
import { CancelticketComponent } from './cancelticket/cancelticket.component';
import {BookingService} from '../app/Service/booking.service';
import { DashboardComponent } from './dashboard/dashboard.component';
import {CancelboxComponent} from './cancelbox/cancelbox.component'
import {PnrenquiryComponent} from './pnrenquiry/pnrenquiry.component'
import { PagenoterrorComponent } from './pagenoterror/pagenoterror.component';
import { BookmyticketComponent } from './bookmyticket/bookmyticket.component';

const routes: Routes = [
  {path:'', redirectTo:'/dhashboard',pathMatch:'full'},
  {path:'header', component:HeaderComponent},
  {path:'mybooking', component:MybookingComponent},
  {path:'cancelticket', component:CancelticketComponent},
  {path:'dhashboard', component:DashboardComponent},
  {path:'cancelbox',component:CancelboxComponent},
  {path:'pnrenquiry',component:PnrenquiryComponent},
  {path:'booking',component:BookmyticketComponent},
  {path:'**',component:PagenoterrorComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule { }
