import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookingService {
  [x: string]: any;
  myBookingUrl="http://localhost:8030/ticket/"
  constructor(private httpclient:HttpClient) { }
  
  getMyBookingDetails(dateValue: String,dateValue1: String,status: String,pageIndex:Number,pageSize:Number):Observable<any>{
    console.log(this.myBookingUrl)
    return this.httpclient.get("http://localhost:8030/ticket/mybooking/1/"+status+"/"+dateValue+"/"+dateValue1+"/"+pageIndex+"/"+pageSize)
  }

  getUpcomingTicketDetails(pageIndex:Number,pageSize:Number):Observable<any>{
    console.log(this.myBookingUrl)
    return this.httpclient.get("http://localhost:8030/ticket/upcoming"+"/"+pageIndex+"/"+pageSize)
  }

  getCanceledTicket(dateValue: String,dateValue1: String):Observable<any>{
    console.log(this.myBookingUrl)
    return this.httpclient.get("http://localhost:8030/cancelticket/"+dateValue+"/"+dateValue1)
  }
  canceledTicket(CancelTicketDto:any):Observable<any>{
    console.log(this.myBookingUrl)
    console.log(CancelTicketDto)
    return this.httpclient.post("http://localhost:8030/cancelticket",CancelTicketDto)
  }

  fetchByPnr(pnr:any,userId:any):Observable<any>{
    console.log(this.myBookingUrl)
    console.log("http://localhost:8030/ticket/fetchbypnr/"+userId+"/"+pnr)
    return this.httpclient.get("http://localhost:8030/ticket/fetchbypnr/"+userId+"/"+pnr)

  }

  automaticTicketBooking():Observable<any>{
    console.log(this.myBookingUrl)
     const respsonseData= this.httpclient.post("http://localhost:8030/ticket",1);
     console.log(respsonseData)
     return respsonseData;
  }

  }


