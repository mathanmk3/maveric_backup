// cancel-dialog.service.ts
import { Injectable, NgModule } from '@angular/core';
import { MatDialog,MatDialogConfig, MatDialogModule } from '@angular/material/dialog';
import { CancelboxComponent } from '../cancelbox/cancelbox.component';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})


export class CancelDialogService {
  ticketid:any;
  constructor(private dialog: MatDialog,private route: Router) {}

  openCancelDialog(customerId: any): void {
    this.ticketid=customerId
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = true;
    this.dialog.open(CancelboxComponent, dialogConfig);
  }

  closeCancelDialog(): void {
    this.dialog.closeAll();
    this.route.navigateByUrl("/cancelticket")
    console.log("DsdAs")

  }
}
