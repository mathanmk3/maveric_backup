import { TestBed } from '@angular/core/testing';

import { CancelDialogService } from './cancel-dialog.service';

describe('CancelDialogService', () => {
  let service: CancelDialogService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CancelDialogService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
