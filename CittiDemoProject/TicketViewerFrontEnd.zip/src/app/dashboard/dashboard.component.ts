import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { year, month } from '@igniteui/material-icons-extended';
import { BookingService } from '../Service/booking.service';
import { CancelDialogService} from '../Service/cancel-dialog.service'
import Swal from 'sweetalert2'
import { catchError, throwError } from 'rxjs';
import { PageEvent } from '@angular/material/paginator';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  customersD!: any;
  errorMessage: string | undefined;
   loading: boolean = true;
   public dateValue: Date = new Date()
   details: any;
   ageSize!: number;
 pageNumber!: number;
 pageEvent!: PageEvent;
   ticketDetails = this.fbr.group({
      ticketid:[],
      tainName: ['gghh'],
      trainNumber: [''],
      startPoint: [''],
      endPoint: [''],
      startDateAndTime: [''],
      destinationDateAndTime: [''],
      pnrNumber: [''],
      seatFromTo: [''],
      noOfSeats: [''],
      boardingPoint: [''],
      boardingDateTime: [''],
      destinationPoint: [''],
      ticketStatus: [''],
      ticketStatusUpdatedDateAndTime: [''],
      journeyDateTime: [''],
      seatStatus: ["Completed"],
   })
  constructor(private fbr: FormBuilder,private route :Router,public CancelDialogService:CancelDialogService,
    public bookingService:BookingService,private ar: ActivatedRoute,private toastr: ToastrService){}  
   ngOnInit(): void {
    this.getUpcomingTicketDetails()  
   }
 
  getUpcomingTicketDetails() {
    const pageIndex=0;
    const pageSize=10
       this.bookingService.getUpcomingTicketDetails(pageIndex,pageSize).pipe(catchError(err=>{
        this.errorMessage=err.error.errorMessgae
        this.customersD=null
        if (err.error.errorCode===500){
          Swal.fire({
            icon: 'error',
            text: 'Server Conncetion Issue',
            showConfirmButton: true,
            confirmButtonColor: 'red'
          })
        }
        return throwError(err)
      })).subscribe((x:any)=> {
        this.errorMessage = undefined;
        this.customersD=x
    })
  }
  openCancelDialog(customerId: any): void {
        this.CancelDialogService.openCancelDialog(customerId);
  }
   
  
onPageChange(event: PageEvent): void {
  console.log('onPageChange')
  this.pageEvent = event;
  const pageIndex = event.pageIndex; 
  const pageSize = event.pageSize; 
  const length = event.length;

  console.log(pageIndex+ " "+pageSize+ " "+length)
  console.log(this.ticketDetails.value);
  this.bookingService.getUpcomingTicketDetails(pageIndex,pageSize).pipe(catchError(err=>{
    this.errorMessage=err.error.errorMessgae
    this.customersD=null
    if (err.error.errorCode===500){
      Swal.fire({
        icon: 'error',
        text: 'Server Conncetion Issue',
        showConfirmButton: true,
        confirmButtonColor: 'red'
      })
    }
    return throwError(err)
  })).subscribe((x:any)=> {
    this.errorMessage = undefined;
  this.customersD=x

})
  
}
 
 
}