import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CancelboxComponent } from './cancelbox.component';

describe('CancelboxComponent', () => {
  let component: CancelboxComponent;
  let fixture: ComponentFixture<CancelboxComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CancelboxComponent]
    });
    fixture = TestBed.createComponent(CancelboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
