import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { BookingService } from '../Service/booking.service';
import { CancelDialogService } from '../Service/cancel-dialog.service';
import { catchError, throwError } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-cancelbox',
  templateUrl: './cancelbox.component.html',
  styleUrls: ['./cancelbox.component.css']
})
export class CancelboxComponent {
  errorMessage: string | undefined;
  customersD!: any;
  CancelTicketDto = this.fbr.group({
    cancelReason:[],
    ticketid:[this.CancelDialogService.ticketid],
    userId:[1]
 })

 constructor(private fbr: FormBuilder,private route :Router,public bookingService:BookingService,
  public CancelDialogService:CancelDialogService,private ar: ActivatedRoute,private toastr: ToastrService){}  
 ngOnInit(): void {
    
 }
  submit(){
    this.bookingService.canceledTicket(this.CancelTicketDto.value).pipe(catchError(err=>{
      this.errorMessage=err.error.errorMessgae
      this.toastr.error(this.errorMessage, 'Error');
      if (err.error.errorCode==='NotBlank'||err.error.errorCode==='NotNull'){
      Swal.fire({
        icon: 'error',
        text: this.errorMessage?.slice(1),
        showConfirmButton: true,
        confirmButtonColor: 'red'
      })
    }
      if (err.error.errorCode===500){
        Swal.fire({
          icon: 'error',
          text: 'Server Conncetion Issue',
          showConfirmButton: true,
          confirmButtonColor: 'red'
        })
    } 
      return throwError(err)
    })).subscribe((x:any)=> {
      this.customersD=x
      console.log(this.route)
      this.CancelDialogService.closeCancelDialog();

    })
  }

}
