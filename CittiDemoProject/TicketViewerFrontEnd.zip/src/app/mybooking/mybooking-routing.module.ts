import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HeaderComponent } from '../header/header.component';
import { MybookingComponent } from './mybooking.component';
import { CancelticketComponent } from '../cancelticket/cancelticket.component';
import {BookingService}from '../Service/booking.service'
import {DashboardComponent} from '../dashboard/dashboard.component'



const routes: Routes = [
  {path:'', redirectTo:'/dhashboard',pathMatch:'full'},
  {path:'header', component:HeaderComponent},
  {path:'mybooking', component:MybookingComponent},
  {path:'cancelticket', component:CancelticketComponent},
  {path:'dhashboard', component:DashboardComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes),],
  exports: [RouterModule],
  providers: [BookingService]

})
export class mybookingRoutingModule { }
