import { Component, HostListener, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {BookingService}from '../Service/booking.service'
import {FormBuilder, FormGroup, FormControl, Validators} from '@angular/forms';
import { catchError, throwError } from 'rxjs';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import Swal from 'sweetalert2';



const today = new Date();
const month = today.getMonth();
const year = today.getFullYear();

@Component({
  selector: 'app-mybooking',
  templateUrl: './mybooking.component.html',
  styleUrls: ['./mybooking.component.css'],
  
})
export class MybookingComponent implements OnInit {
 customersD!: any;
 errorMessage: string | undefined;
 pageSize!: number;
 pageNumber!: number;
 pageEvent!: PageEvent;

 loading: boolean = true;
  public dateValue: Date = new Date()
  public dateValue1: Date = new Date() 
    campaignTwo = new FormGroup({
    start: new FormControl(new Date(year, month, 15)),
    end: new FormControl(new Date(year, month, 19)),
  });
  private getYesterday(): Date {
    const yesterday = new Date(this.dateValue);
    yesterday.setDate(this.dateValue.getDate() - 1);
    return yesterday;
  }
  details: any;
  ticketDetails = this.fbr.group({
     tainName: ['gghh'],
     trainNumber: [''],
     startPoint: [''],
     endPoint: [''],
     startDateAndTime: [''],
     destinationDateAndTime: [''],
     PNRNumber: [''],
     seatFromTo: [''],
     noOfSeats: [''],
     boardingPoint: [''],
     destinationPoint: [''],
     ticketStatus: ['COMPLETED',[Validators.required]],
     BookedDateTime: [this.getYesterday()],
     BookedToTime: [this.dateValue1],
     ticketStatusUpdatedDateAndTime: [''],
     journeyDateTime: [''],
     seatStatus: ["Completed"],
  })
  constructor(private fbr: FormBuilder,private route :Router,public bookingService:BookingService,
    private ar: ActivatedRoute,private matPaginator: MatPaginator){}  
  ngOnInit(): void {
    this.errorMessage = undefined;
   this.getBookingDeatilsOnLoading(this.dateValue,this.dateValue1,"Completed")  
  }

getBookingDeatilsOnLoading(dateValue: Date,dateValue1: Date,status: string) {

      const getFromDate=this.dateFormatter(this.getYesterday());
      const getToDate=this.dateFormatter(dateValue1);
    const pageIndex=0;
    const pageSize=10
      this.bookingService.getMyBookingDetails(getFromDate, getToDate,status,pageIndex,pageSize).pipe(catchError(err=>{
        this.customersD=null
        this.errorMessage=err.error.errorMessgae
        if (err.error.errorCode===500){
          Swal.fire({
            icon: 'error',
            text: 'Server Conncetion Issue',
            showConfirmButton: true,
            confirmButtonColor: 'red'
          })
        }
        return throwError(err)
      })).subscribe((x:any)=> {
      this.customersD=x

  
    })
  }

  getBookingDetails(){
    console.log(this.ticketDetails.value);
    const bookedDateTime = this.ticketDetails.value.BookedDateTime?this.ticketDetails.value.BookedDateTime : "";
    const bookedToDateTime = this.ticketDetails.value.BookedToTime?this.ticketDetails.value.BookedToTime : "";
    const status = this.ticketDetails.value.ticketStatus?this.ticketDetails.value.ticketStatus : "";
    const getFromDate=this.dateFormatter( new Date(bookedDateTime));
    const getToDate=this.dateFormatter( new Date(bookedToDateTime));
    const pageIndex=0;
    const pageSize=10
    this.bookingService.getMyBookingDetails(getFromDate, getToDate,status,pageIndex,pageSize).pipe(catchError(err=>{
      this.customersD=null
      this.errorMessage=err.error.errorMessgae
      if (err.error.errorCode===500){
        Swal.fire({
          icon: 'error',
          text: 'Server Conncetion Issue',
          showConfirmButton: true,
          confirmButtonColor: 'red'
        })
      }
      return throwError(err)
    })).subscribe((x:any)=> {
      this.errorMessage = undefined;
    this.customersD=x

  })
}


dateFormatter(dateValue: Date){
const year = dateValue.getFullYear();
const month = (dateValue.getMonth() + 1).toString().padStart(2, '0'); // Month is zero-based
const day = dateValue.getDate().toString().padStart(2, '0');
const hours = dateValue.getHours().toString().padStart(2, '0');
const minutes = dateValue.getMinutes().toString().padStart(2, '0');
const seconds = dateValue.getSeconds().toString().padStart(2, '0');
const newDateString = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
return newDateString;

}

onPageChange(event: PageEvent): void {
  console.log('onPageChange')
  this.pageEvent = event;
  const pageIndex = event.pageIndex; 
  const pageSize = event.pageSize; 
  const length = event.length;

  console.log(pageIndex+ " "+pageSize+ " "+length)
  console.log(this.ticketDetails.value);
  const bookedDateTime = this.ticketDetails.value.BookedDateTime?this.ticketDetails.value.BookedDateTime : "";
  const bookedToDateTime = this.ticketDetails.value.BookedToTime?this.ticketDetails.value.BookedToTime : "";
  const status = this.ticketDetails.value.ticketStatus?this.ticketDetails.value.ticketStatus : "";
  const getFromDate=this.dateFormatter( new Date(bookedDateTime));
  const getToDate=this.dateFormatter( new Date(bookedToDateTime));
  this.bookingService.getMyBookingDetails(getFromDate, getToDate,status,pageIndex,pageSize).pipe(catchError(err=>{
    this.errorMessage=err.error.errorMessgae
    this.customersD=null
    if (err.error.errorCode===500){
      Swal.fire({
        icon: 'error',
        text: 'Server Conncetion Issue',
        showConfirmButton: true,
        confirmButtonColor: 'red'
      })
    }
    return throwError(err)
  })).subscribe((x:any)=> {
    this.errorMessage = undefined;
    console.log(x.error);
  this.customersD=x

})
  
}

}
