import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { BookingService } from '../Service/booking.service';
import { catchError } from 'rxjs';
import Swal from 'sweetalert2';


const today = new Date();
const month = today.getMonth();
const year = today.getFullYear();
@Component({
  selector: 'app-cancelticket',
  templateUrl: './cancelticket.component.html',
  styleUrls: ['./cancelticket.component.css']
})
export class CancelticketComponent implements OnInit {
  customersD!: any;
  errorMessage: string | undefined;
   loading: boolean = true;
   public dateValue: Date = new Date()
   public dateValue1: Date = new Date() 
     campaignTwo = new FormGroup({
     start: new FormControl(new Date(year, month, 15)),
     end: new FormControl(new Date(year, month, 19)),
   });
  
   private getYesterday(): Date {
     const yesterday = new Date(this.dateValue);
     yesterday.setDate(this.dateValue.getDate() - 10);
     return yesterday;
   }
   details: any;
   ticketDetails = this.fbr.group({
      tainName: ['gghh'],
      trainNumber: [''],
      startPoint: [''],
      endPoint: [''],
      startDateAndTime: [''],
      destinationDateAndTime: [''],
      PNRNumber: [''],
      seatFromTo: [''],
      noOfSeats: [''],
      boardingPoint: [''],
      destinationPoint: [''],
      ticketStatus: [''],
      BookedDateTime: [this.getYesterday()],
      BookedToTime: [this.dateValue1],
      ticketStatusUpdatedDateAndTime: [''],
      journeyDateTime: [''],
      seatStatus: ["Completed"],
   })
   constructor(private fbr: FormBuilder,private route :Router,public bookingService:BookingService,private ar: ActivatedRoute,){}  
   ngOnInit(): void {
    this.getCanceledTicketOnLoading(this.dateValue,this.dateValue1)  
   }
 
   getCanceledTicketOnLoading(dateValue: Date,dateValue1: Date) {
 
       const getFromDate=this.dateFormatter(this.getYesterday());
       const getToDate=this.dateFormatter(dateValue1);
       this.bookingService.getCanceledTicket(getFromDate, getToDate).pipe(catchError(err=>{
        this.customersD=null
        this.errorMessage=err.error.errorMessgae
        if (err.error.errorCode===500){
          Swal.fire({
            icon: 'error',
            text: 'Server Conncetion Issue',
            showConfirmButton: true,
            confirmButtonColor: 'red'
          })
        }
        return throwError(err)
       
      })).subscribe((x:any)=> {
        this.errorMessage = undefined;
        this.customersD=x
    })
   }
 
   getCanceledTicket(){
     console.log(this.ticketDetails.value);
     const bookedDateTime = this.ticketDetails.value.BookedDateTime?this.ticketDetails.value.BookedDateTime : "";
     const bookedToDateTime = this.ticketDetails.value.BookedToTime?this.ticketDetails.value.BookedToTime : "";
     const getFromDate=this.dateFormatter( new Date(bookedDateTime));
     const getToDate=this.dateFormatter( new Date(bookedToDateTime));
     this.bookingService.getCanceledTicket(getFromDate, getToDate).pipe(catchError(err=>{
      this.errorMessage=err.error.errorMessgae
      this.customersD=null
      if (err.error.errorCode===500){
        Swal.fire({
          icon: 'error',
          text: 'Server Conncetion Issue',
          showConfirmButton: true,
          confirmButtonColor: 'red'
        })
      }
      return throwError(err)
    })).subscribe((x:any)=> {
      this.errorMessage = undefined;
      this.customersD=x
  })
 }
 
 
 dateFormatter(dateValue: Date){
 const year = dateValue.getFullYear();
 const month = (dateValue.getMonth() + 1).toString().padStart(2, '0'); // Month is zero-based
 const day = dateValue.getDate().toString().padStart(2, '0');
 const hours = dateValue.getHours().toString().padStart(2, '0');
 const minutes = dateValue.getMinutes().toString().padStart(2, '0');
 const seconds = dateValue.getSeconds().toString().padStart(2, '0');
 const newDateString = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
 return newDateString;
 
 }
 
 }
function throwError(err: any): any {
  throw new Error('Function not implemented.');
}

