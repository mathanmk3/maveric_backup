import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PnrenquiryComponent } from './pnrenquiry.component';

describe('PnrenquiryComponent', () => {
  let component: PnrenquiryComponent;
  let fixture: ComponentFixture<PnrenquiryComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PnrenquiryComponent]
    });
    fixture = TestBed.createComponent(PnrenquiryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
