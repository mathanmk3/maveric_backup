import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { BookingService } from '../Service/booking.service';
import { catchError } from 'rxjs/internal/operators/catchError';
import { throwError } from 'rxjs/internal/observable/throwError';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-pnrenquiry',
  templateUrl: './pnrenquiry.component.html',
  styleUrls: ['./pnrenquiry.component.css']
})
export class PnrenquiryComponent {

  
  customersD!: any;
  errorMessage: string | undefined;
  pnr = this.fbr.group({
    pnrNumber:[ '',[Validators.required]],
    userId:[1]
 })

 constructor(private fbr: FormBuilder,private route :Router,public bookingService:BookingService,private ar: ActivatedRoute,){}  
 ngOnInit(): void {
  this.errorMessage= undefined;
 }
  submit(){
    console.log(this.pnr.value.pnrNumber)
     const pnrValue=this.pnr.value.pnrNumber?.trim();
     console.log(pnrValue?.length)

    if (pnrValue?.length==0){
      Swal.fire({
        icon: 'error',
        text: 'PNR Should not be empty',
        showConfirmButton: true,
        confirmButtonColor: 'red'
        
      })
      return;
    }
    this.bookingService.fetchByPnr(this.pnr.value.pnrNumber,this.pnr.value.userId).pipe(catchError(err=>{
      this.errorMessage=err.error.errorMessgae
      this.customersD=null
      console.log(this.errorMessage)
      if (err.error.errorCode===500){
        Swal.fire({
          icon: 'error',
          text: 'Server Conncetion Issue',
          showConfirmButton: true,
          confirmButtonColor: 'red'
        })
      }
      return throwError(err)
    })).subscribe((x:any)=> {
      this.errorMessage = undefined;
      this.customersD=x
  })

}
}
