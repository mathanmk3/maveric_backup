import { Component } from '@angular/core';

@Component({
  selector: 'app-pagenoterror',
  templateUrl: './pagenoterror.component.html',
  styleUrls: ['./pagenoterror.component.css']
})
export class PagenoterrorComponent {

}
