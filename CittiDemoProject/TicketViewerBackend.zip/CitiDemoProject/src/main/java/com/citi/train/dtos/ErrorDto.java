package com.citi.train.dtos;

import lombok.Data;

@Data
public class ErrorDto {

	private String errorMessgae;
	private String errorCode;

}
