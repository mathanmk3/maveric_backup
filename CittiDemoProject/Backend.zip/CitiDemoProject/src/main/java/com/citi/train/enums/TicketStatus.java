package com.citi.train.enums;

public enum TicketStatus {

    CANCALLED,YETTOSTART,COMPLETED;
}
